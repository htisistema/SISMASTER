This package contains:

DOSPrinter.exe - demo version of the actual program.
Language.ini   - UI translations. You can edit it. Distribute it only if using /LNG switch.
License.txt    - terms and conditions. You must distribute it together with DOSPrinter.exe.
Readme.txt     - this file. Do not distribute it.
RunMe.bat      - example of DOSPrinter usage. Do not distribute it.
Sample.bmp     - example for image printing. Do not distribute it.
Sample.prn     - example of document to print. Do not distribute it.



How to start:

Unzip this package in an empty folder.
Run RunMe.bat - this will start DOSPrinter program and print out the file Sample.prn. 
Note a new icon in the systray. You can change the settings there. Instead Sample.prn, specify a file of yours.


Check the site www.geocities.com/dosprint for a complete documentation regarding DOSPrinter.